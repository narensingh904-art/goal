
self.addEventListener('install',e=>{
 e.waitUntil(caches.open('goals-v1').then(c=>c.addAll([
 './goals_dashboard_final_v4.html','./manifest.webmanifest'
 ])));
});
self.addEventListener('fetch',e=>{
 e.respondWith(caches.match(e.request).then(r=>r||fetch(e.request)));
});
